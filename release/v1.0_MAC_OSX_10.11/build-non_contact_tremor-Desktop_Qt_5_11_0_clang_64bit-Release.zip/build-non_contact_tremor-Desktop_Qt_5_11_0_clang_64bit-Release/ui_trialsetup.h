/********************************************************************************
** Form generated from reading UI file 'trialsetup.ui'
**
** Created by: Qt User Interface Compiler version 5.11.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_TRIALSETUP_H
#define UI_TRIALSETUP_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QDialog>
#include <QtWidgets/QDialogButtonBox>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_TrialSetup
{
public:
    QGridLayout *gridLayout;
    QGroupBox *groupBox_2;
    QGridLayout *gridLayout_3;
    QPushButton *chooseDirectoryButton;
    QLineEdit *directoryPathLineEdit;
    QGroupBox *outputSignalsBox;
    QGridLayout *gridLayout_5;
    QCheckBox *analogOutSignalCheckBox;
    QCheckBox *digitalOutSignalACheckBox;
    QCheckBox *digitalOutSignalBCheckBox;
    QGroupBox *groupBox;
    QGridLayout *gridLayout_2;
    QLineEdit *sampleRateLineEdit;
    QLabel *label;
    QDialogButtonBox *buttonBox;
    QGroupBox *groupBox_3;
    QGridLayout *gridLayout_4;
    QLineEdit *collectionTimeoutLineEdit;
    QLabel *label_2;
    QGroupBox *groupBox_4;
    QGridLayout *gridLayout_6;
    QLineEdit *fileNameEdit;

    void setupUi(QDialog *TrialSetup)
    {
        if (TrialSetup->objectName().isEmpty())
            TrialSetup->setObjectName(QStringLiteral("TrialSetup"));
        TrialSetup->resize(350, 369);
        TrialSetup->setModal(true);
        gridLayout = new QGridLayout(TrialSetup);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        groupBox_2 = new QGroupBox(TrialSetup);
        groupBox_2->setObjectName(QStringLiteral("groupBox_2"));
        gridLayout_3 = new QGridLayout(groupBox_2);
        gridLayout_3->setObjectName(QStringLiteral("gridLayout_3"));
        chooseDirectoryButton = new QPushButton(groupBox_2);
        chooseDirectoryButton->setObjectName(QStringLiteral("chooseDirectoryButton"));
        chooseDirectoryButton->setFocusPolicy(Qt::StrongFocus);

        gridLayout_3->addWidget(chooseDirectoryButton, 2, 0, 1, 1);

        directoryPathLineEdit = new QLineEdit(groupBox_2);
        directoryPathLineEdit->setObjectName(QStringLiteral("directoryPathLineEdit"));
        directoryPathLineEdit->setFocusPolicy(Qt::NoFocus);
        directoryPathLineEdit->setReadOnly(true);

        gridLayout_3->addWidget(directoryPathLineEdit, 1, 0, 1, 1);


        gridLayout->addWidget(groupBox_2, 3, 0, 1, 2);

        outputSignalsBox = new QGroupBox(TrialSetup);
        outputSignalsBox->setObjectName(QStringLiteral("outputSignalsBox"));
        gridLayout_5 = new QGridLayout(outputSignalsBox);
        gridLayout_5->setObjectName(QStringLiteral("gridLayout_5"));
        analogOutSignalCheckBox = new QCheckBox(outputSignalsBox);
        analogOutSignalCheckBox->setObjectName(QStringLiteral("analogOutSignalCheckBox"));
        analogOutSignalCheckBox->setFocusPolicy(Qt::StrongFocus);

        gridLayout_5->addWidget(analogOutSignalCheckBox, 0, 0, 1, 1);

        digitalOutSignalACheckBox = new QCheckBox(outputSignalsBox);
        digitalOutSignalACheckBox->setObjectName(QStringLiteral("digitalOutSignalACheckBox"));
        digitalOutSignalACheckBox->setFocusPolicy(Qt::StrongFocus);

        gridLayout_5->addWidget(digitalOutSignalACheckBox, 1, 0, 1, 1);

        digitalOutSignalBCheckBox = new QCheckBox(outputSignalsBox);
        digitalOutSignalBCheckBox->setObjectName(QStringLiteral("digitalOutSignalBCheckBox"));
        digitalOutSignalBCheckBox->setFocusPolicy(Qt::StrongFocus);

        gridLayout_5->addWidget(digitalOutSignalBCheckBox, 2, 0, 1, 1);


        gridLayout->addWidget(outputSignalsBox, 0, 0, 2, 1);

        groupBox = new QGroupBox(TrialSetup);
        groupBox->setObjectName(QStringLiteral("groupBox"));
        gridLayout_2 = new QGridLayout(groupBox);
        gridLayout_2->setObjectName(QStringLiteral("gridLayout_2"));
        sampleRateLineEdit = new QLineEdit(groupBox);
        sampleRateLineEdit->setObjectName(QStringLiteral("sampleRateLineEdit"));
        sampleRateLineEdit->setAlignment(Qt::AlignCenter);

        gridLayout_2->addWidget(sampleRateLineEdit, 0, 0, 1, 1);

        label = new QLabel(groupBox);
        label->setObjectName(QStringLiteral("label"));
        QFont font;
        font.setPointSize(13);
        label->setFont(font);
        label->setLineWidth(1);

        gridLayout_2->addWidget(label, 0, 1, 1, 1);


        gridLayout->addWidget(groupBox, 0, 1, 1, 1);

        buttonBox = new QDialogButtonBox(TrialSetup);
        buttonBox->setObjectName(QStringLiteral("buttonBox"));
        buttonBox->setFocusPolicy(Qt::StrongFocus);
        buttonBox->setOrientation(Qt::Horizontal);
        buttonBox->setStandardButtons(QDialogButtonBox::Cancel|QDialogButtonBox::Ok);

        gridLayout->addWidget(buttonBox, 4, 0, 1, 2);

        groupBox_3 = new QGroupBox(TrialSetup);
        groupBox_3->setObjectName(QStringLiteral("groupBox_3"));
        gridLayout_4 = new QGridLayout(groupBox_3);
        gridLayout_4->setObjectName(QStringLiteral("gridLayout_4"));
        collectionTimeoutLineEdit = new QLineEdit(groupBox_3);
        collectionTimeoutLineEdit->setObjectName(QStringLiteral("collectionTimeoutLineEdit"));
        collectionTimeoutLineEdit->setEnabled(false);
        collectionTimeoutLineEdit->setAlignment(Qt::AlignCenter);

        gridLayout_4->addWidget(collectionTimeoutLineEdit, 0, 0, 1, 1);

        label_2 = new QLabel(groupBox_3);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setFont(font);

        gridLayout_4->addWidget(label_2, 0, 1, 1, 1);


        gridLayout->addWidget(groupBox_3, 1, 1, 1, 1);

        groupBox_4 = new QGroupBox(TrialSetup);
        groupBox_4->setObjectName(QStringLiteral("groupBox_4"));
        gridLayout_6 = new QGridLayout(groupBox_4);
        gridLayout_6->setObjectName(QStringLiteral("gridLayout_6"));
        fileNameEdit = new QLineEdit(groupBox_4);
        fileNameEdit->setObjectName(QStringLiteral("fileNameEdit"));

        gridLayout_6->addWidget(fileNameEdit, 0, 0, 1, 1);


        gridLayout->addWidget(groupBox_4, 2, 0, 1, 2);

        QWidget::setTabOrder(analogOutSignalCheckBox, digitalOutSignalACheckBox);
        QWidget::setTabOrder(digitalOutSignalACheckBox, digitalOutSignalBCheckBox);
        QWidget::setTabOrder(digitalOutSignalBCheckBox, sampleRateLineEdit);
        QWidget::setTabOrder(sampleRateLineEdit, collectionTimeoutLineEdit);
        QWidget::setTabOrder(collectionTimeoutLineEdit, chooseDirectoryButton);

        retranslateUi(TrialSetup);
        QObject::connect(buttonBox, SIGNAL(accepted()), TrialSetup, SLOT(accept()));
        QObject::connect(buttonBox, SIGNAL(rejected()), TrialSetup, SLOT(reject()));

        QMetaObject::connectSlotsByName(TrialSetup);
    } // setupUi

    void retranslateUi(QDialog *TrialSetup)
    {
        TrialSetup->setWindowTitle(QApplication::translate("TrialSetup", "Trial setup", nullptr));
#ifndef QT_NO_TOOLTIP
        groupBox_2->setToolTip(QApplication::translate("TrialSetup", "Select the directory to save data that will be collected.", nullptr));
#endif // QT_NO_TOOLTIP
        groupBox_2->setTitle(QApplication::translate("TrialSetup", "Select directory", nullptr));
        chooseDirectoryButton->setText(QApplication::translate("TrialSetup", "Choose directory", nullptr));
#ifndef QT_NO_TOOLTIP
        outputSignalsBox->setToolTip(QApplication::translate("TrialSetup", "Enable the output signals (you may choose more than one).", nullptr));
#endif // QT_NO_TOOLTIP
        outputSignalsBox->setTitle(QApplication::translate("TrialSetup", "Select the output signals", nullptr));
        analogOutSignalCheckBox->setText(QApplication::translate("TrialSetup", "Analog output signal", nullptr));
        digitalOutSignalACheckBox->setText(QApplication::translate("TrialSetup", "Digital output signal A", nullptr));
        digitalOutSignalBCheckBox->setText(QApplication::translate("TrialSetup", "Digital output signal B", nullptr));
        groupBox->setTitle(QApplication::translate("TrialSetup", "Sample rate", nullptr));
        sampleRateLineEdit->setText(QString());
        label->setText(QApplication::translate("TrialSetup", "Hz", nullptr));
        groupBox_3->setTitle(QApplication::translate("TrialSetup", "Collection timeout", nullptr));
        collectionTimeoutLineEdit->setText(QString());
        label_2->setText(QApplication::translate("TrialSetup", "s", nullptr));
        groupBox_4->setTitle(QApplication::translate("TrialSetup", "File name", nullptr));
#ifndef QT_NO_TOOLTIP
        fileNameEdit->setToolTip(QApplication::translate("TrialSetup", "Avoid accents and spaces.", nullptr));
#endif // QT_NO_TOOLTIP
    } // retranslateUi

};

namespace Ui {
    class TrialSetup: public Ui_TrialSetup {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_TRIALSETUP_H
