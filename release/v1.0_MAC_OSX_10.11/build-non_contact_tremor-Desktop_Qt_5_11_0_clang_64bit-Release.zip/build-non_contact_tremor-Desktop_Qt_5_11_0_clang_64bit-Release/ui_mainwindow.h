/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.11.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtGui/QIcon>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenu>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPlainTextEdit>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>
#include "qcustomplot.h"

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QAction *actionConnect;
    QAction *actionDisconnect;
    QAction *actionConfigure;
    QAction *actionQuit;
    QAction *actionPatient;
    QAction *actionTrialSetup;
    QAction *actionClear;
    QAction *actionAbout;
    QAction *actionAboutQt;
    QAction *actionStart;
    QAction *actionStop;
    QAction *actionSave;
    QAction *actionPlotSignals;
    QWidget *centralWidget;
    QHBoxLayout *horizontalLayout_2;
    QGroupBox *serialMonitorGroupBox;
    QHBoxLayout *horizontalLayout;
    QPlainTextEdit *serialMonitorTextEdit;
    QWidget *verticalWidget;
    QVBoxLayout *verticalLayout;
    QGroupBox *xAxisGroupBox;
    QVBoxLayout *verticalLayout_3;
    QVBoxLayout *verticalLayout_2;
    QCustomPlot *xAxisPlot;
    QGroupBox *yAxisGroupBox;
    QVBoxLayout *verticalLayout_5;
    QVBoxLayout *verticalLayout_4;
    QCustomPlot *yAxisPlot;
    QMenuBar *menuBar;
    QMenu *menuCalls;
    QMenu *menuTools;
    QMenu *menuHelp;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QStringLiteral("MainWindow"));
        MainWindow->resize(900, 700);
        QIcon icon;
        icon.addFile(QStringLiteral(":/images/matrix-hand.png"), QSize(), QIcon::Normal, QIcon::Off);
        MainWindow->setWindowIcon(icon);
        actionConnect = new QAction(MainWindow);
        actionConnect->setObjectName(QStringLiteral("actionConnect"));
        QIcon icon1;
        icon1.addFile(QStringLiteral(":/images/usb-connect.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionConnect->setIcon(icon1);
        QFont font;
        font.setPointSize(14);
        actionConnect->setFont(font);
        actionDisconnect = new QAction(MainWindow);
        actionDisconnect->setObjectName(QStringLiteral("actionDisconnect"));
        QIcon icon2;
        icon2.addFile(QStringLiteral(":/images/usb-disconnect.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionDisconnect->setIcon(icon2);
        actionDisconnect->setFont(font);
        actionConfigure = new QAction(MainWindow);
        actionConfigure->setObjectName(QStringLiteral("actionConfigure"));
        QIcon icon3;
        icon3.addFile(QStringLiteral(":/images/usb-settings.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionConfigure->setIcon(icon3);
        actionConfigure->setFont(font);
        actionQuit = new QAction(MainWindow);
        actionQuit->setObjectName(QStringLiteral("actionQuit"));
        QIcon icon4;
        icon4.addFile(QStringLiteral(":/images/close.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionQuit->setIcon(icon4);
        actionQuit->setFont(font);
        actionPatient = new QAction(MainWindow);
        actionPatient->setObjectName(QStringLiteral("actionPatient"));
        actionPatient->setEnabled(false);
        QIcon icon5;
        icon5.addFile(QStringLiteral(":/images/patient-profile.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionPatient->setIcon(icon5);
        actionPatient->setFont(font);
        actionTrialSetup = new QAction(MainWindow);
        actionTrialSetup->setObjectName(QStringLiteral("actionTrialSetup"));
        QIcon icon6;
        icon6.addFile(QStringLiteral(":/images/system-controller.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionTrialSetup->setIcon(icon6);
        actionTrialSetup->setFont(font);
        actionClear = new QAction(MainWindow);
        actionClear->setObjectName(QStringLiteral("actionClear"));
        QIcon icon7;
        icon7.addFile(QStringLiteral(":/images/trash.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionClear->setIcon(icon7);
        actionClear->setFont(font);
        actionAbout = new QAction(MainWindow);
        actionAbout->setObjectName(QStringLiteral("actionAbout"));
        actionAbout->setFont(font);
        actionAboutQt = new QAction(MainWindow);
        actionAboutQt->setObjectName(QStringLiteral("actionAboutQt"));
        actionAboutQt->setFont(font);
        actionStart = new QAction(MainWindow);
        actionStart->setObjectName(QStringLiteral("actionStart"));
        QIcon icon8;
        icon8.addFile(QStringLiteral(":/images/play.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionStart->setIcon(icon8);
        actionStart->setFont(font);
        actionStop = new QAction(MainWindow);
        actionStop->setObjectName(QStringLiteral("actionStop"));
        QIcon icon9;
        icon9.addFile(QStringLiteral(":/images/stop.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionStop->setIcon(icon9);
        actionStop->setFont(font);
        actionSave = new QAction(MainWindow);
        actionSave->setObjectName(QStringLiteral("actionSave"));
        QIcon icon10;
        icon10.addFile(QStringLiteral(":/images/save-file-option.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionSave->setIcon(icon10);
        actionPlotSignals = new QAction(MainWindow);
        actionPlotSignals->setObjectName(QStringLiteral("actionPlotSignals"));
        QIcon icon11;
        icon11.addFile(QStringLiteral(":/images/signal.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionPlotSignals->setIcon(icon11);
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        horizontalLayout_2 = new QHBoxLayout(centralWidget);
        horizontalLayout_2->setSpacing(6);
        horizontalLayout_2->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_2->setObjectName(QStringLiteral("horizontalLayout_2"));
        serialMonitorGroupBox = new QGroupBox(centralWidget);
        serialMonitorGroupBox->setObjectName(QStringLiteral("serialMonitorGroupBox"));
        QSizePolicy sizePolicy(QSizePolicy::Preferred, QSizePolicy::Preferred);
        sizePolicy.setHorizontalStretch(1);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(serialMonitorGroupBox->sizePolicy().hasHeightForWidth());
        serialMonitorGroupBox->setSizePolicy(sizePolicy);
        serialMonitorGroupBox->setFont(font);
        horizontalLayout = new QHBoxLayout(serialMonitorGroupBox);
        horizontalLayout->setSpacing(6);
        horizontalLayout->setContentsMargins(11, 11, 11, 11);
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        serialMonitorTextEdit = new QPlainTextEdit(serialMonitorGroupBox);
        serialMonitorTextEdit->setObjectName(QStringLiteral("serialMonitorTextEdit"));
        serialMonitorTextEdit->setFont(font);
        serialMonitorTextEdit->setUndoRedoEnabled(false);
        serialMonitorTextEdit->setReadOnly(true);
        serialMonitorTextEdit->setCenterOnScroll(false);

        horizontalLayout->addWidget(serialMonitorTextEdit);


        horizontalLayout_2->addWidget(serialMonitorGroupBox);

        verticalWidget = new QWidget(centralWidget);
        verticalWidget->setObjectName(QStringLiteral("verticalWidget"));
        QSizePolicy sizePolicy1(QSizePolicy::Preferred, QSizePolicy::Preferred);
        sizePolicy1.setHorizontalStretch(2);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(verticalWidget->sizePolicy().hasHeightForWidth());
        verticalWidget->setSizePolicy(sizePolicy1);
        verticalLayout = new QVBoxLayout(verticalWidget);
        verticalLayout->setSpacing(6);
        verticalLayout->setContentsMargins(11, 11, 11, 11);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        xAxisGroupBox = new QGroupBox(verticalWidget);
        xAxisGroupBox->setObjectName(QStringLiteral("xAxisGroupBox"));
        QSizePolicy sizePolicy2(QSizePolicy::Expanding, QSizePolicy::Expanding);
        sizePolicy2.setHorizontalStretch(0);
        sizePolicy2.setVerticalStretch(0);
        sizePolicy2.setHeightForWidth(xAxisGroupBox->sizePolicy().hasHeightForWidth());
        xAxisGroupBox->setSizePolicy(sizePolicy2);
        xAxisGroupBox->setFont(font);
        verticalLayout_3 = new QVBoxLayout(xAxisGroupBox);
        verticalLayout_3->setSpacing(6);
        verticalLayout_3->setContentsMargins(11, 11, 11, 11);
        verticalLayout_3->setObjectName(QStringLiteral("verticalLayout_3"));
        verticalLayout_2 = new QVBoxLayout();
        verticalLayout_2->setSpacing(6);
        verticalLayout_2->setObjectName(QStringLiteral("verticalLayout_2"));
        xAxisPlot = new QCustomPlot(xAxisGroupBox);
        xAxisPlot->setObjectName(QStringLiteral("xAxisPlot"));

        verticalLayout_2->addWidget(xAxisPlot);


        verticalLayout_3->addLayout(verticalLayout_2);


        verticalLayout->addWidget(xAxisGroupBox);

        yAxisGroupBox = new QGroupBox(verticalWidget);
        yAxisGroupBox->setObjectName(QStringLiteral("yAxisGroupBox"));
        sizePolicy2.setHeightForWidth(yAxisGroupBox->sizePolicy().hasHeightForWidth());
        yAxisGroupBox->setSizePolicy(sizePolicy2);
        yAxisGroupBox->setFont(font);
        verticalLayout_5 = new QVBoxLayout(yAxisGroupBox);
        verticalLayout_5->setSpacing(6);
        verticalLayout_5->setContentsMargins(11, 11, 11, 11);
        verticalLayout_5->setObjectName(QStringLiteral("verticalLayout_5"));
        verticalLayout_4 = new QVBoxLayout();
        verticalLayout_4->setSpacing(6);
        verticalLayout_4->setObjectName(QStringLiteral("verticalLayout_4"));
        yAxisPlot = new QCustomPlot(yAxisGroupBox);
        yAxisPlot->setObjectName(QStringLiteral("yAxisPlot"));

        verticalLayout_4->addWidget(yAxisPlot);


        verticalLayout_5->addLayout(verticalLayout_4);


        verticalLayout->addWidget(yAxisGroupBox);


        horizontalLayout_2->addWidget(verticalWidget);

        MainWindow->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(MainWindow);
        menuBar->setObjectName(QStringLiteral("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 900, 22));
        menuCalls = new QMenu(menuBar);
        menuCalls->setObjectName(QStringLiteral("menuCalls"));
        menuTools = new QMenu(menuBar);
        menuTools->setObjectName(QStringLiteral("menuTools"));
        menuHelp = new QMenu(menuBar);
        menuHelp->setObjectName(QStringLiteral("menuHelp"));
        MainWindow->setMenuBar(menuBar);
        mainToolBar = new QToolBar(MainWindow);
        mainToolBar->setObjectName(QStringLiteral("mainToolBar"));
        mainToolBar->setAutoFillBackground(false);
        mainToolBar->setIconSize(QSize(38, 38));
        MainWindow->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(MainWindow);
        statusBar->setObjectName(QStringLiteral("statusBar"));
        statusBar->setFont(font);
        MainWindow->setStatusBar(statusBar);

        menuBar->addAction(menuCalls->menuAction());
        menuBar->addAction(menuTools->menuAction());
        menuBar->addAction(menuHelp->menuAction());
        menuCalls->addAction(actionConnect);
        menuCalls->addAction(actionDisconnect);
        menuCalls->addSeparator();
        menuCalls->addAction(actionSave);
        menuCalls->addAction(actionPlotSignals);
        menuCalls->addSeparator();
        menuCalls->addAction(actionQuit);
        menuTools->addAction(actionPatient);
        menuTools->addAction(actionTrialSetup);
        menuTools->addSeparator();
        menuTools->addAction(actionConfigure);
        menuTools->addSeparator();
        menuTools->addAction(actionClear);
        menuHelp->addAction(actionAbout);
        menuHelp->addAction(actionAboutQt);
        mainToolBar->addAction(actionPatient);
        mainToolBar->addAction(actionTrialSetup);
        mainToolBar->addSeparator();
        mainToolBar->addAction(actionConnect);
        mainToolBar->addAction(actionDisconnect);
        mainToolBar->addAction(actionConfigure);
        mainToolBar->addSeparator();
        mainToolBar->addAction(actionStart);
        mainToolBar->addAction(actionStop);
        mainToolBar->addSeparator();
        mainToolBar->addAction(actionSave);
        mainToolBar->addAction(actionPlotSignals);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "Non contact sensor data logger 1.0", nullptr));
        actionConnect->setText(QApplication::translate("MainWindow", "Connect", nullptr));
#ifndef QT_NO_TOOLTIP
        actionConnect->setToolTip(QApplication::translate("MainWindow", "Connect to serial port", nullptr));
#endif // QT_NO_TOOLTIP
        actionDisconnect->setText(QApplication::translate("MainWindow", "Disconnect", nullptr));
#ifndef QT_NO_TOOLTIP
        actionDisconnect->setToolTip(QApplication::translate("MainWindow", "Disconnect from serial port", nullptr));
#endif // QT_NO_TOOLTIP
        actionConfigure->setText(QApplication::translate("MainWindow", "Configure serial", nullptr));
#ifndef QT_NO_TOOLTIP
        actionConfigure->setToolTip(QApplication::translate("MainWindow", "Configure serial port connection", nullptr));
#endif // QT_NO_TOOLTIP
        actionQuit->setText(QApplication::translate("MainWindow", "Quit", nullptr));
#ifndef QT_NO_SHORTCUT
        actionQuit->setShortcut(QApplication::translate("MainWindow", "Ctrl+Q", nullptr));
#endif // QT_NO_SHORTCUT
        actionPatient->setText(QApplication::translate("MainWindow", "Patient", nullptr));
#ifndef QT_NO_TOOLTIP
        actionPatient->setToolTip(QApplication::translate("MainWindow", "Edit patient data", nullptr));
#endif // QT_NO_TOOLTIP
        actionTrialSetup->setText(QApplication::translate("MainWindow", "Trial Setup", nullptr));
#ifndef QT_NO_TOOLTIP
        actionTrialSetup->setToolTip(QApplication::translate("MainWindow", "Trial setup", nullptr));
#endif // QT_NO_TOOLTIP
        actionClear->setText(QApplication::translate("MainWindow", "Clear", nullptr));
#ifndef QT_NO_TOOLTIP
        actionClear->setToolTip(QApplication::translate("MainWindow", "Clear data", nullptr));
#endif // QT_NO_TOOLTIP
        actionAbout->setText(QApplication::translate("MainWindow", "About", nullptr));
#ifndef QT_NO_TOOLTIP
        actionAbout->setToolTip(QApplication::translate("MainWindow", "About program", nullptr));
#endif // QT_NO_TOOLTIP
        actionAboutQt->setText(QApplication::translate("MainWindow", "About Qt", nullptr));
        actionStart->setText(QApplication::translate("MainWindow", "Start", nullptr));
#ifndef QT_NO_TOOLTIP
        actionStart->setToolTip(QApplication::translate("MainWindow", "Starts the collect", nullptr));
#endif // QT_NO_TOOLTIP
        actionStop->setText(QApplication::translate("MainWindow", "Stop", nullptr));
#ifndef QT_NO_TOOLTIP
        actionStop->setToolTip(QApplication::translate("MainWindow", "Stops the collect", nullptr));
#endif // QT_NO_TOOLTIP
        actionSave->setText(QApplication::translate("MainWindow", "Save", nullptr));
#ifndef QT_NO_TOOLTIP
        actionSave->setToolTip(QApplication::translate("MainWindow", "Save data in this PC", nullptr));
#endif // QT_NO_TOOLTIP
        actionPlotSignals->setText(QApplication::translate("MainWindow", "Plot signals", nullptr));
#ifndef QT_NO_TOOLTIP
        actionPlotSignals->setToolTip(QApplication::translate("MainWindow", "Plot the recorded signals", nullptr));
#endif // QT_NO_TOOLTIP
        serialMonitorGroupBox->setTitle(QApplication::translate("MainWindow", "Serial monitor (read-only)", nullptr));
        xAxisGroupBox->setTitle(QApplication::translate("MainWindow", "X-Axis", nullptr));
        yAxisGroupBox->setTitle(QApplication::translate("MainWindow", "Y-Axis", nullptr));
        menuCalls->setTitle(QApplication::translate("MainWindow", "Calls", nullptr));
        menuTools->setTitle(QApplication::translate("MainWindow", "Tools", nullptr));
        menuHelp->setTitle(QApplication::translate("MainWindow", "Help", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
